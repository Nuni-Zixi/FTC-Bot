##

<div align="center">  
    <h1> FullTClash</h1>  
    <p>🤖 A Telegram bot that operates based on the Clash core </p>  
    <p>English        <a href="https://github.com/AirportR/fulltclash/blob/dev/README.md">简体中文</a></p>   
    <a href="https://fulltclash.gitbook.io/fulltclash-doc"><img src="https://img.shields.io/static/v1?message=doc&color=blue&logo=micropython&label=FullTClash"></a> 
    <img src="https://img.shields.io/github/license/AirportR/fulltclash">  
    <a href="https://app.codacy.com/gh/AirportR/fulltclash/dashboard?utm_source=gh&utm_medium=referral&utm_content=&utm_campaign=Badge_grade"><img src="https://app.codacy.com/project/badge/Grade/389b2787eb7647dfad486ccaa70eabf4"></a>  
    <a href="https://github.com/AirportR/fulltclash/issues"><img src="https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat"></a>  
    <br>  
    <a href="https://github.com/AirportR/fulltclash/"><img src="https://img.shields.io/github/stars/AirportR/fulltclash?style=social"></a>  
   <a href = "https://t.me/fulltclash"><img src="https://img.shields.io/static/v1?style=social&logo=telegram&label=channel&message=channel" ></a>  
   <br>  
   <br>  
</div>

## Attention !
I don't think there are any native English users for this project, so English documentation is not available.